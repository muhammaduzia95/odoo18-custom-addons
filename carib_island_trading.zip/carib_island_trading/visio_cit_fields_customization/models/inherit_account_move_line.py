from odoo import models, fields, api


class AccountMoveLine(models.Model):
    _inherit = "account.move.line"

    default_code = fields.Char(related="product_id.default_code", store=True, readonly=True)
    barcode = fields.Char(related="product_id.barcode", store=True, readonly=True)
    categ_id = fields.Many2one(comodel_name="product.category", related="product_id.categ_id", store=True,
                               readonly=True)
    size = fields.Char(related="product_id.size", store=True, readonly=True)
    # units_quantity = fields.Float(string="Pcs Order", compute='_compute_units_quantity', store=True)
    units_quantity = fields.Float(string="Pcs Order", store=True)
    price_per_unit = fields.Float(string="Pcs Price", compute="_compute_per_unit_price", store=True)
    per_unit = fields.Many2one('uom.uom', string="Per Unit", compute='_compute_per_unit', store=True, readonly=True)

    # @api.depends('quantity', 'product_id.cit_case_qty')
    # def _compute_units_quantity(self):
    #     for line in self:
    #         case_qty = line.product_id.cit_case_qty or 0
    #         line.units_quantity = line.quantity * case_qty if case_qty > 0 else 0.0
    #         print(f"[DEBUG _compute_units_quantity] Line ID: {line.id}, Quantity: {line.quantity}, "
    #               f"Case Qty: {case_qty}, Units Quantity: {line.units_quantity}")

    @api.depends('price_unit', 'product_id.cit_case_qty')
    def _compute_per_unit_price(self):
        for line in self:
            case_qty = line.product_id.cit_case_qty or 0
            if line.price_unit and case_qty > 0:
                line.price_per_unit = line.price_unit / case_qty
            else:
                line.price_per_unit = 0.0
            print(f"[DEBUG _compute_per_unit_price] Line ID: {line.id}, Price Unit: {line.price_unit}, "
                  f"Case Qty: {case_qty}, Price per Unit: {line.price_per_unit}")

    @api.depends('product_id')
    def _compute_per_unit(self):
        for line in self:
            if line.product_id.uom_id and line.product_id.uom_id.category_id:
                unit_uom = self.env['uom.uom'].search([
                    ('category_id', '=', line.product_id.uom_id.category_id.id),
                    ('uom_type', '=', 'reference')
                ], limit=1)
                line.per_unit = unit_uom
                print(f"[DEBUG _compute_per_unit] Line ID: {line.id}, Product: {line.product_id.display_name}, "
                      f"Unit UoM: {unit_uom.display_name}")
            else:
                line.per_unit = False
                print(
                    f"[DEBUG _compute_per_unit] Line ID: {line.id}, Product: {line.product_id.display_name if line.product_id else 'N/A'}, "
                    f"Unit UoM: None")

    region_cit_inv = fields.Char(string='Region')
    hs_code_cit_inv = fields.Char(string='H.S Code')



