# visio_cit_fields_customization/models/sale_order_line.py
from odoo import models, fields, api


class SaleOrderLine(models.Model):
    _inherit = 'sale.order.line'

    default_code = fields.Char(related='product_id.default_code', store=True, readonly=True)
    barcode = fields.Char(related='product_id.barcode', store=True, readonly=True)
    categ_id = fields.Many2one(related='product_id.categ_id', comodel_name='product.category', store=True,
                               readonly=True)
    size = fields.Char(related="product_id.size", store=True, readonly=True, )
    per_unit_price = fields.Float(string="Pcs Price", compute="_compute_per_unit_price", store=True)

    @api.depends('price_unit', 'product_id.cit_case_qty')
    def _compute_per_unit_price(self):
        for line in self:
            case_qty = line.product_id.cit_case_qty or 0
            if line.price_unit and case_qty > 0:
                line.per_unit_price = line.price_unit / case_qty
            else:
                line.per_unit_price = 0.0

    per_unit = fields.Many2one(
        'uom.uom', string="Per Unit", compute='_compute_per_unit', store=True, readonly=True)

    @api.depends('product_id')
    def _compute_per_unit(self):
        for line in self:
            if line.product_id.uom_id and line.product_id.uom_id.category_id:
                unit_uom = self.env['uom.uom'].search([
                    ('category_id', '=', line.product_id.uom_id.category_id.id),
                    ('uom_type', '=', 'reference')
                ], limit=1)
                line.per_unit = unit_uom
            else:
                line.per_unit = False

    units_quantity = fields.Float(string="Pcs Order", compute="_compute_units_quantity", store=True)

    @api.depends('product_uom_qty', 'product_id.cit_case_qty')
    def _compute_units_quantity(self):
        for line in self:
            case_qty = line.product_id.cit_case_qty or 0
            line.units_quantity = line.product_uom_qty * case_qty

    region_cit = fields.Char(string="Region")
    hs_code_cit = fields.Char(string="H.S Code")
    translated_product_name = fields.Char(string="Translated Product Name", invisible="1")
    vendor_price_cit = fields.Float(string='Vendor Unit Price (PR)',
                                    help='Temporary unit price used only by the Purchase Request workflow.')

    # Sync the Region, HS Code fields with the sale order
    def _prepare_invoice_line(self, **optional_values):
        vals = super()._prepare_invoice_line(**optional_values)

        vals.update({
            'region_cit_inv': self.region_cit,
            'hs_code_cit_inv': self.hs_code_cit,
            'units_quantity': self.units_quantity,
            'quantity': self.product_uom_qty,
        })
        print("Vals:", vals)
        return vals
