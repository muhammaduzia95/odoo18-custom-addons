# \carib_island_trading\visio_cit_purchase_request\models\inherit_purchase_order.py
from odoo import models, fields, api


class PurchaseOrder(models.Model):
    _inherit = 'purchase.order'

    logistics_ids = fields.One2many('purchase.order.logistics', 'order_id', string="Logistics")

    # def _sync_logistics_to_sale_order(self):
    #     for po in self:
    #         if not po.origin:
    #             continue
    #         so = self.env['sale.order'].search([('name', '=', po.origin)], limit=1)
    #         if not so:
    #             continue
    #
    #         so.logistics_ids.filtered(lambda l: l.shipping_method_id.id in
    #                                             po.logistics_ids.mapped('shipping_method_id').ids and
    #                                             l.charge_to_customer_synced).unlink()
    #
    #         for pol in po.logistics_ids.filtered('charge_to_customer'):
    #             self.env['sale.order.logistics'].create({
    #                 'order_id': so.id,
    #                 'shipping_method_id': pol.shipping_method_id.id,
    #                 'sub_shipping_id': pol.sub_shipping_id.id,
    #                 'price': pol.price,
    #                 'charge_to_customer_synced': True,
    #             })

    # PO / Notebook / Page / Logistic Details fields
    logistics_company_id = fields.Many2one("sub.shipping", string="Logistics Company", )
    notes_cit = fields.Char(string="Notes")
    packing_request = fields.Char(string="Packing Request")
    pickup_address = fields.Char(string="Pickup Address")
    delivery_address = fields.Char(string="Delivery Address")
    incoterms_cit = fields.Char(string="Incoterms")
    weight_cit = fields.Char(string="Weight")
    booking_number_cit = fields.Char(string="Booking Number")
    bol_status = fields.Boolean(string="BOL Status")
    shipment_status = fields.Char(string="Shipment Status")
    # charge_to_customer = fields.Float(string="Charge to Customer", store=True)
    charge_to_customer = fields.Float(
        string="Charge to Customer",
        compute="_compute_charge_to_customer",
        store=False,
        readonly=True,
    )

    document_attachment_ids = fields.Many2many(comodel_name='ir.attachment',
                                               string="Attachments", )



    # helper to find linked SO via origin field
    def _get_related_sale_order(self):
        self.ensure_one()
        if self.origin:
            return self.env["sale.order"].search([("name", "=", self.origin)], limit=1)
        return False

    # Syncing above fields to the fields of SO
    def _sync_to_sale_order(self):
        for po in self:
            so = po._get_related_sale_order()
            if so:
                so.write({
                    "logistics_company_so": po.logistics_company_id.id,
                    "notes_cit_so": po.notes_cit,
                    "packing_request_so": po.packing_request,
                    "pickup_address_so": po.pickup_address,
                    "delivery_address_so": po.delivery_address,
                    "incoterms_cit_so": po.incoterms_cit,
                    "weight_cit_so": po.weight_cit,
                    "booking_number_cit_so": po.booking_number_cit,
                    "bol_status_so": po.bol_status,
                    "shipment_status_so": po.shipment_status,
                    "charge_to_customer_so": po.charge_to_customer,
                    "document_attachment_so": [(6, 0, po.document_attachment_ids.ids)],
                })

    def create(self, vals):  # Adding data to the fields
        po = super().create(vals)
        po._sync_to_sale_order()
        return po

    def write(self, vals):  # Updating data to the fields
        res = super().write(vals)
        self._sync_to_sale_order()
        return res

    def unlink(self):  # Removing data to the fields
        for po in self:
            so = po._get_related_sale_order()
            if so:
                so.write({
                    "logistics_company_so": False,
                    "notes_cit_so": False,
                    "packing_request_so": False,
                    "pickup_address_so": False,
                    "delivery_address_so": False,
                    "incoterms_cit_so": False,
                    "weight_cit_so": False,
                    "booking_number_cit_so": False,
                    "bol_status_so": False,
                    "shipment_status_so": False,
                    "charge_to_customer_so": 0.0,
                    "document_attachment_so": [(5, 0, 0)],
                })
        return super().unlink()

    # Getting the price value from Logistics page to Logistics Details page -> Charge to Customer field
    # @api.onchange('logistics_company_id')
    # def _onchange_logistics_company_id(self):
    #     print(f"[DEBUG][onchange] logistics_company_id={self.logistics_company_id}")
    #     if self.logistics_company_id:
    #         matching_line = self.logistics_ids.filtered(
    #             lambda l: l.sub_shipping_id == self.logistics_company_id
    #         )
    #         print(f"[DEBUG][onchange] Matching lines: {matching_line.ids}")
    #         if matching_line:
    #             self.charge_to_customer = matching_line[0].price
    #             print(f"[DEBUG][onchange] charge_to_customer set to {self.charge_to_customer}")
    #         else:
    #             print("[DEBUG][onchange] No matching line found, leaving charge_to_customer as is")

    # Make charge_to_customer a computed field that persists (set compute="_compute_charge_to_customer", store=True, readonly=True)
    @api.depends('logistics_company_id', 'logistics_ids.sub_shipping_id', 'logistics_ids.price')
    def _compute_charge_to_customer(self):
        for po in self:
            debug_hdr = f"[DEBUG][compute] PO({po.id})"
            if po.logistics_company_id:
                line = po.logistics_ids.filtered(lambda l: l.sub_shipping_id == po.logistics_company_id)[:1]
                if line:
                    print(
                        f"{debug_hdr} company={po.logistics_company_id.id} -> match line {line.id} price={line.price}")
                    po.charge_to_customer = line.price
                else:
                    print(
                        f"{debug_hdr} company={po.logistics_company_id.id} -> no matching logistics line; keep existing")
                    # keep existing value (do not reset)
            else:
                print(f"{debug_hdr} no logistics_company_id; keep existing")
                # keep existing value (do not reset)


class PurchaseOrderLogistics(models.Model):
    _name = 'purchase.order.logistics'
    _description = 'Purchase Order Logistics'

    order_id = fields.Many2one('purchase.order', ondelete='cascade', required=True)
    shipping_method_id = fields.Many2one('shipping.methods', string="Shipping Method", required=True)
    sub_shipping_id = fields.Many2one('sub.shipping', string="Logistics Company")
    # price = fields.Float(string="Price")
    # charge_to_customer = fields.Boolean(string="Charge to Customer",)

    company_email_cit = fields.Char(string="Company Email")
    origin_custom_clearance = fields.Char(string="Origin Custom Clearance")
    pickup_address_port = fields.Char(string="Pickup Address/Port")
    delivery_address_port = fields.Char(string="Delivery Address/Port")
    destination_customs_clearance = fields.Char(string="Destination Customs Clearance")
    price_quoted_ff = fields.Char(string="Price Quoted by FF")
    container_size_sea = fields.Char(string="Container Size if Sea")
    transit_time = fields.Float(string="Transit Time", help="Time in hours/days", digits=(16, 2))
    quote_validation_date = fields.Date(string="Quote Validation Date")
    price = fields.Float(string="Price Offered to Customer")

    # @api.model
    # def create(self, vals):
    #     rec = super().create(vals)
    #     if vals.get('charge_to_customer'):
    #         rec.order_id._sync_logistics_to_sale_order()
    #     return rec
    #
    # def write(self, vals):
    #     res = super().write(vals)
    #     trigger_fields = {'shipping_method_id', 'sub_shipping_id', 'price', 'charge_to_customer'}
    #     if trigger_fields.intersection(vals):
    #         for rec in self:
    #             rec.order_id._sync_logistics_to_sale_order()
    #     return res
