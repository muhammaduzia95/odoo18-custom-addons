# carib_island_trading\visio_cit_sale_customization\models\inherit_account_move.py
from odoo import models, fields


class AccountMove(models.Model):
    _inherit = 'account.move'

    attachment_ids_in = fields.Many2many('ir.attachment', string='Attachments',)
