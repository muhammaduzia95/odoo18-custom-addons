# visio_cit_sale_customization/models/inherit_sale_order.py
from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError


class SaleOrder(models.Model):
    _inherit = 'sale.order'

    def action_create_purchase_request(self):
        self.ensure_one()

        self.env['purchase.request'].create({'sale_order_id': self.id, 'note_pr': self.note, })

        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': "Purchase Request Created",
                'message': f"Purchase Request for {self.name} has been created.",
                'type': 'success',
                'sticky': False,
                'next': {
                    'type': 'ir.actions.client',
                    'tag': 'reload',
                },
            },
        }

    def action_view_purchase_order(self):
        self.ensure_one()
        action = self.env.ref('purchase.action_rfq').read()[0]
        action['domain'] = [('origin', '=', self.name)]
        return action

    markup_percent = fields.Integer(
        string="Markup (%)",
        help="Enter the markup percentage to apply on this order."
    )

    logistics_ids = fields.One2many('sale.order.logistics', 'order_id', string="Logistics")

    @api.onchange('markup_percent')
    def _onchange_markup_percent_propagate(self):
        for order in self:
            for line in order.order_line:
                line.markup_percent_line = order.markup_percent

    purchase_order_count = fields.Integer(
        string="Purchase Orders", compute='_compute_purchase_order_count')

    def _compute_purchase_order_count(self):
        for rec in self:
            rec.purchase_order_count = self.env['purchase.order'].search_count(
                [('origin', '=', rec.name)]
            )

    def action_view_purchase_orders(self):
        self.ensure_one()
        return {
            'name': "Related Purchase Orders",
            'type': 'ir.actions.act_window',
            'res_model': 'purchase.order',
            'view_mode': 'list,form',
            'domain': [('origin', '=', self.name)],
            'context': {'default_origin': self.name},
        }

    attachment_ids_so = fields.Many2many('ir.attachment', string='Attachments', )

    po_state = fields.Char(string="PO State", compute='_compute_po_state', readonly=True)

    def _compute_po_state(self):
        state_dict = dict(self.env['purchase.order']._fields['state'].selection)

        for order in self:
            purchase_orders = self.env['purchase.order'].search([('origin', '=', order.name)])

            labels = [
                state_dict.get(state_key, state_key)
                for state_key in purchase_orders.mapped('state')]

            order.po_state = ', '.join(sorted(set(labels))) if labels else 'No PO Against this Sale Order'

    quote_validation_cit = fields.Date(string="Quote Validation Date")
    purchase_request_ids = fields.One2many('purchase.request', 'sale_order_id', string='Purchase Requests',
                                           readonly=True, )
    purchase_request_created = fields.Boolean(string="Purchase Request Created",
                                              compute='_compute_purchase_request_created', store=True, )

    @api.depends('purchase_request_ids')
    def _compute_purchase_request_created(self):
        for order in self:
            order.purchase_request_created = bool(order.purchase_request_ids)

    # note field on sale order should not be added in narration on invoice
    def _prepare_invoice(self):
        print("_prepare_invoice action triggered")
        vals = super()._prepare_invoice()
        vals.pop('narration', None)  # or: vals['narration'] = False
        return vals

    # Sale Order/ Notebook/ Page/ Fields
    logistics_company_so = fields.Many2one("sub.shipping", string="Logistics Company")
    so_logistics_company = fields.Many2one("shipping.methods", string="Logistics Company")
    notes_cit_so = fields.Char(string="Notes")
    packing_request_so = fields.Char(string="Packing Request")
    pickup_address_so = fields.Char(string="Pickup Address")
    delivery_address_so = fields.Char(string="Delivery Address")
    incoterms_cit_so = fields.Char(string="Incoterms")
    weight_cit_so = fields.Char(string="Weight")
    booking_number_cit_so = fields.Char(string="Booking Number")
    bol_status_so = fields.Boolean(string="BOL Status")
    shipment_status_so = fields.Char(string="Shipment Status")
    charge_to_customer_so = fields.Float(string="Charge to Customer")
    document_attachment_so = fields.Many2many('ir.attachment', 'sale_order_ir_attachments_rel', 'sale_order_id',
                                              'attachment_id', string="Attachments")

    logistics_details_accepted = fields.Boolean(string="Logistics Details Accepted", default=False, copy=False)

    def _ensure_logistics_details_line(self):
        """ Add or update a sale.order.line for the logistics company
        with the charge_to_customer_so price. """
        for order in self:
            if not order.so_logistics_company:
                raise UserError(_("Please select a Logistics Company first."))

            product = self.env['product.product'].search(
                [('name', '=', order.so_logistics_company.name)], limit=1
            )
            if not product:
                raise UserError(
                    _("No product found with name '%s' (needed for logistics line).")
                    % order.so_logistics_company.name
                )

            so_line = order.order_line.filtered(lambda l: l.product_id == product)[:1]
            if so_line:
                # update existing line
                so_line.price_unit = order.charge_to_customer_so
            else:
                # create new line
                order.order_line.create({
                    'order_id': order.id,
                    'product_id': product.id,
                    'name': product.name,
                    'product_uom_qty': 1,
                    'product_uom': product.uom_id.id,
                    'price_unit': order.charge_to_customer_so or 0.0,
                })

    def action_accept_logistics_details(self):
        print("action_accept_logistics_details, Triggered")
        for order in self:
            if not order.charge_to_customer_so or order.charge_to_customer_so <= 0:
                raise ValidationError(_("Charge to Customer should be greater than 0"))

            order._ensure_logistics_details_line()
            order.logistics_details_accepted = True
        return True


class SaleOrderLogistics(models.Model):
    _name = 'sale.order.logistics'
    _description = 'Sale Order Logistics'

    order_id = fields.Many2one('sale.order', string="Sale Order", ondelete='cascade', required=True)
    shipping_method_id = fields.Many2one('shipping.methods', string="Shipping Method", required=True)
    sub_shipping_id = fields.Many2one('sub.shipping', string="Sub Shipping")
    price = fields.Float(string="Price")
    accepted_by_customer = fields.Boolean(string="Accepted by Customer")

    charge_to_customer_synced = fields.Boolean(default=False, copy=False)  # this field is for syncing purpose

    def _ensure_shipping_product_line(self):
        """
        Find (or create) a sale.order.line on the parent SO that
        represents this shipping method, and set its price.
        """
        for l in self:
            order = l.order_id
            product = l.env['product.product'].search(
                [('name', '=', l.shipping_method_id.name)], limit=1
            )
            if not product:
                raise UserError(
                    _("No product found with name '%s' (needed for shipping line).")
                    % l.shipping_method_id.name
                )

            so_line = order.order_line.filtered(lambda x: x.product_id == product)[:1]
            if so_line:
                so_line.price_unit = l.price
            else:
                order.order_line.create({
                    'order_id': order.id,
                    'product_id': product.id,
                    'name': product.name,
                    'product_uom_qty': 1,
                    'product_uom': product.uom_id.id,
                    'price_unit': l.price,
                })

    @api.model
    def create(self, vals):
        record = super().create(vals)
        if vals.get('accepted_by_customer'):
            record._ensure_shipping_product_line()
        return record

    def write(self, vals):
        res = super().write(vals)
        if 'accepted_by_customer' in vals and vals['accepted_by_customer']:
            for rec in self:
                rec._ensure_shipping_product_line()
        elif {'price', 'shipping_method_id'}.intersection(vals) and self.filtered('accepted_by_customer'):
            for rec in self.filtered('accepted_by_customer'):
                rec._ensure_shipping_product_line()
        return res

    def action_accept_logistics(self):
        for rec in self:
            rec.accepted_by_customer = True
        return True


class SaleOrderLine(models.Model):
    _inherit = 'sale.order.line'

    # 1.  Field for markup %
    markup_percent_line = fields.Integer(
        string="Markup (%)",
        help="Line-level markup (defaults from order header)."
    )

    # 2.  Show correct subtotal/total instantly in the form view
    @api.onchange('markup_percent_line', 'price_unit', 'product_uom_qty', 'discount')
    def _onchange_markup_live(self):
        for line in self:
            unit_mk = line.price_unit * (1 + line.markup_percent_line / 100.0)
            subtotal = unit_mk * line.product_uom_qty * (1 - (line.discount or 0.0) / 100.0)
            line.price_subtotal = subtotal  # UI refresh
            line.price_total = subtotal  # UI refresh

            print(f"[ONCHANGE] {line.product_id.display_name} | "
                  f"unit={line.price_unit} qty={line.product_uom_qty} "
                  f"markup%={line.markup_percent_line} -> subtotal={subtotal}")

    # 3.  Back-end amount computation (stored values)
    @api.depends('product_uom_qty', 'discount', 'price_unit',
                 'tax_id', 'markup_percent_line')
    def _compute_amount(self):
        for line in self:
            unit_mk = line.price_unit * (1 + line.markup_percent_line / 100.0)
            subtotal = unit_mk * line.product_uom_qty * (1 - (line.discount or 0.0) / 100.0)

            # No taxes in your scenario; keep 0.0 for price_tax.
            line.update({
                'price_subtotal': subtotal,
                'price_total': subtotal,
                'price_tax': 0.0,
            })

            print(f"[COMPUTE]  {line.product_id.display_name} | "
                  f"unit={line.price_unit} qty={line.product_uom_qty} "
                  f"markup%={line.markup_percent_line} subtotal={subtotal}")

    def _prepare_base_line_for_taxes_computation(self, **kwargs):
        """
        Extend parent logic: apply line-level markup to price_unit
        but keep compatibility with new keyword args (e.g. special_mode).
        """
        vals = super()._prepare_base_line_for_taxes_computation(**kwargs)

        if self.markup_percent_line:
            new_unit = vals['price_unit'] * (1 + self.markup_percent_line / 100.0)
            vals['price_unit'] = new_unit
        return vals

    # 5.  Default new lines to header-level markup
    @api.model
    def create(self, vals):
        if vals.get('order_id') and not vals.get('markup_percent_line'):
            vals['markup_percent_line'] = self.env['sale.order'].browse(
                vals['order_id']
            ).markup_percent
        return super().create(vals)
